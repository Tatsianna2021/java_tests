package by.belvebteh.misevich.test.restfull_test1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfullTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(RestfullTest1Application.class, args);
	}

}
